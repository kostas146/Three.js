import * as THREE from "three";
import { config } from '../utils/Config';


import { createGround,
    createRoom,
    createLighting,
    handleResize,
    createAndAddMesh } from '../js/Room.js';

import { createWindow, createDoor, handleLoadButton } from '../js/DoorWindow';

import { loadModel } from '../js/ModelLoader';
import Measurements from "../js/Measurments";
import {setupModelLoader} from "../js/UI";
import {OrbitControls} from "three/examples/jsm/controls/OrbitControls";
import {EffectComposer} from "three/addons/postprocessing/EffectComposer";
import {RenderPass} from "three/addons/postprocessing/RenderPass";
import {UnrealBloomPass} from "three/addons/postprocessing/UnrealBloomPass";
export function initScene() {
    // Create a new scene, camera, and renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });

    // Configure renderer settings
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setSize(window.innerWidth, window.innerHeight);

    // Append the renderer to a DOM element
    document.getElementById("three-js-canvas").appendChild(renderer.domElement);

    // Set up camera position and orientation
    const roomCenter = new THREE.Vector3(0, config.roomSize.height / 2, 0);
    camera.position.set(config.roomSize.width / 2, config.roomSize.height, config.roomSize.depth / 2);
    camera.lookAt(roomCenter);

    // Return the scene, camera, and renderer
    return { scene, camera, renderer };
}

export function initOrbitControls(camera, renderer) {
    // Create a new OrbitControls instance with the camera and renderer
    const orbitControls = new OrbitControls(camera, renderer.domElement);

    // Configure OrbitControls settings
    orbitControls.enableDamping = true;
    orbitControls.dampingFactor = 0.05;
    orbitControls.screenSpacePanning = false;
    orbitControls.maxPolarAngle = Math.PI / 2;

    // Return the OrbitControls instance
    return orbitControls;
}
export function main() {
    // Initialize the scene, camera, and renderer
    const { scene, camera, renderer } = initScene();

    // Initialize the OrbitControls for camera movement
    const orbitControls = initOrbitControls(camera, renderer);

    // Create the ground
    createGround(scene);

    // Create the room walls and store them in the 'walls' array
    let walls = createRoom(
        scene,
        config.roomSize.width,
        config.roomSize.height,
        config.roomSize.depth,
        'http://localhost/wordpress/wp-content/uploads/2023/11/brick-wall-background-seamless-texture-pattern-illustration-free-vector.jpg'
    );

    // Ensure that walls are available here
    console.log("Walls array after creation:", walls);

    // Add event listeners for the load window and load door buttons
    document.getElementById('load-window-button').addEventListener('click', () => {
        console.log("Walls array inside event listener:", walls);
        handleLoadButton(scene, 'window', walls);
    });
    document.getElementById('load-door-button').addEventListener('click', () => handleLoadButton(scene, 'door', walls));

    // Create lighting
    createLighting(scene);

    // Handle window resize
    handleResize(camera, renderer);

    // Create a window and a door on specific walls
    createWindow(scene, walls[2], 1.5, 2, 0);
    createDoor(scene, walls[1], 1, 3, 1);

    // Set up model loader UI
    setupModelLoader(scene, camera, renderer, orbitControls);

    // Set up post-processing effects
    const composer = new EffectComposer(renderer);
    const renderPass = new RenderPass(scene, camera);
    composer.addPass(renderPass);
    const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 0.85);
    composer.addPass(bloomPass);

    // Animation loop
    function animate() {
        requestAnimationFrame(animate);
        composer.render();
    }

    // Start the animation loop
    animate();
}
