<template>
  <div>
    <p>Furniture Component</p>
  </div>
</template>

<script>
export default {
  name: 'FurnitureComponent'
}
</script>
