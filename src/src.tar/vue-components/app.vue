<template>
  <div>
    <p>Main App</p>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
