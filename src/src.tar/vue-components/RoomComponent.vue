<template>
  <div>
    <p>Room Component</p>
  </div>
</template>

<script>
export default {
  name: 'RoomComponent'
}
</script>
