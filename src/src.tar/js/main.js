import { main, initScene } from '../scenes/MainScene';

main();
