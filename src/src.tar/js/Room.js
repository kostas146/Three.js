import * as THREE from "three";
import { config } from '../utils/Config';
import {handleLoadButton} from "./DoorWindow";
const scene = new THREE.Scene();
let createdWalls = [];

// Function to create and add a mesh to the scene
export function createAndAddMesh(scene, geometry, material, position, rotation = new THREE.Vector3()) {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(...position);
    mesh.rotation.set(...rotation);
    scene.add(mesh);
    return mesh;
}

export function createGround(scene) {
    const texture = new THREE.TextureLoader().load(config.groundTextureURL);
    texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(25, 25);

    const material = new THREE.MeshStandardMaterial({ map: texture });
    createAndAddMesh(scene, new THREE.PlaneGeometry(50, 50), material, [0, -0.5, 0], [-Math.PI / 2, 0, 0]);
}

export function createRoom(scene, width, height, depth, textureURL) {
    // Clear existing room
    removeExistingObjects(scene, 'wall');

    // Create walls and floor with new dimensions
    const wallDimensions = [
        [width, height, config.wallThickness, 0, height / 2, depth / 2], // Front wall
        [width, height, config.wallThickness, 0, height / 2, -depth / 2], // Back wall
        [config.wallThickness, height, depth, width / 2, height / 2, 0], // Right wall
        [config.wallThickness, height, depth, -width / 2, height / 2, 0], // Left wall
        [width, config.wallThickness, depth, 0, -config.wallThickness / 2, 0] // Floor
    ];

    wallDimensions.forEach((dim, index) => {
        const wall = createWall(scene, dim, textureURL);
        wall.userData.type = 'wall';
        wall.userData.index = index; // Store the wall index for reference
        createdWalls.push(wall);

        // Log the index of each wall
        console.log(`Wall created with index: ${index}`);
    });

    return createdWalls;
}
function createWall(scene, dimensions, textureURL) {
    const [width, height, depth, x, y, z] = dimensions;
    const texture = new THREE.TextureLoader().load(textureURL);
    texture.encoding = THREE.sRGBEncoding;

    const material = new THREE.MeshStandardMaterial({ map: texture, side: THREE.DoubleSide });
    const wall = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), material);
    wall.position.set(x, y, z);
    scene.add(wall);
    return wall;
}




export function createLighting(scene) {
    const spotLight = new THREE.SpotLight(0xffffff, 1, 50, Math.PI / 6, 0.1, 2);
    spotLight.position.set(0, 10, 10);
    spotLight.castShadow = true;
    scene.add(spotLight);

    scene.add(new THREE.AmbientLight(0xffffff, 0.7));
}

export function handleResize(camera, renderer) {
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}



// Other utility functions
function removeExistingObjects(scene, objectType) {
    const objectsToRemove = scene.children.filter(obj => obj.userData.type === objectType);
    objectsToRemove.forEach(obj => scene.remove(obj));
}

// Event listener attachment
// Event listener attachment
document.addEventListener('DOMContentLoaded', () => {
    const loadWindowButton = document.getElementById('load-window-button');
    const loadDoorButton = document.getElementById('load-door-button');

    // Pass the 'walls' array to handleLoadButton
    loadWindowButton.addEventListener('click', () => handleLoadButton(scene, 'window', createdWalls));
    loadDoorButton?.addEventListener('click', () => handleLoadButton(scene, 'door', createdWalls));

    const drawRoomButton = document.getElementById('draw-room-button');
    drawRoomButton.addEventListener('click', () => {
        const width = parseFloat(document.getElementById('room-width').value);
        const height = parseFloat(document.getElementById('room-height').value);
        const depth = parseFloat(document.getElementById('room-depth').value);

        // Update the global config object
        config.roomSize.width = width;
        config.roomSize.height = height;
        config.roomSize.depth = depth;

        // Redraw the room with updated dimensions
        createRoom(scene, width, height, depth);
    });
});
