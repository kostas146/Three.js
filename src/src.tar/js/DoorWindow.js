// DoorWindow.js

import * as THREE from "three";
import { config } from '../utils/Config';
// Unified function to create windows and doors
function createOpening(scene, width, height, distanceFromWall, distanceFromFloor, wallIndex, material) {
    console.log("createOpening - width:", width);
    console.log("createOpening - height:", height);
    console.log("createOpening - distanceFromWall:", distanceFromWall);
    console.log("createOpening - distanceFromFloor:", distanceFromFloor);
    console.log("createOpening - wallIndex:", wallIndex);

    const {
        clampedWidth,
        clampedHeight,
        clampedDistanceFromWall,
        clampedDistanceFromFloor
    } = adjustDimensionsAndPosition(width, height, distanceFromWall, distanceFromFloor, wallIndex);

    console.log("createOpening - clampedWidth:", clampedWidth);
    console.log("createOpening - clampedHeight:", clampedHeight);
    console.log("createOpening - clampedDistanceFromWall:", clampedDistanceFromWall);
    console.log("createOpening - clampedDistanceFromFloor:", clampedDistanceFromFloor);

    const geometry = new THREE.PlaneGeometry(clampedWidth, clampedHeight);
    const mesh = new THREE.Mesh(geometry, material);

    let xPosition = 0, zPosition = 0, yRotation = 0;
    if (wallIndex === '1') {
        xPosition = clampedDistanceFromWall - (config.roomSize.width / 2);
        zPosition = (config.roomSize.depth / 2);
    } else if (wallIndex === '2') {
        xPosition = clampedDistanceFromWall - (config.roomSize.width / 2);
        zPosition = -(config.roomSize.depth / 2);
    } else if (wallIndex === '3') {
        xPosition = -(config.roomSize.width / 2);
        zPosition = clampedDistanceFromWall - (config.roomSize.depth / 2);
        yRotation = Math.PI / 2;
    } else if (wallIndex === '4') {
        xPosition = (config.roomSize.width / 2);
        zPosition = clampedDistanceFromWall - (config.roomSize.depth / 2);
        yRotation = Math.PI / 2;
    }

    console.log("createOpening - xPosition:", xPosition);
    console.log("createOpening - zPosition:", zPosition);
    console.log("createOpening - yRotation:", yRotation);

    mesh.position.set(xPosition, clampedDistanceFromFloor + clampedHeight / 2, zPosition);
    mesh.rotation.y = yRotation;
    scene.add(mesh);
    return mesh;
}
export function createWindow(scene, width, height, distanceFromFloor, distanceFromWall, wallIndex) {
    const windowMaterial = new THREE.MeshBasicMaterial({ color: 0x00FFFF, transparent: true, opacity: 0.5, side: THREE.DoubleSide });
    return createOpening(scene, width, height, distanceFromWall, distanceFromFloor, wallIndex, windowMaterial);
}

export function createDoor(scene, width, height, distanceFromWall, wallIndex) {
    const doorMaterial = new THREE.MeshBasicMaterial({ color: 0x654321, transparent: true, opacity: 0.7, side: THREE.DoubleSide });
    return createOpening(scene, width, height, distanceFromWall, 0, wallIndex, doorMaterial); // Doors start at floor level
}

export function handleLoadButton(scene, type, walls) {
    console.log("Walls array in handleLoadButton:", walls);

    if (!Array.isArray(walls) || walls.length === 0) {
        console.error('Walls array is undefined or empty');
        return;
    }
    const inputs = gatherInputValues(type);
    if (!inputs) return;

    const selectedWallIndex = getSelectedWallIndex();

    // Check if the selected wall index is valid
    if (selectedWallIndex < 0 || selectedWallIndex >= walls.length) {
        console.error(`Selected wall index ${selectedWallIndex} is out of bounds`);
        return;
    }

    const selectedWall = walls[selectedWallIndex];

    if (!selectedWall) {
        console.error(`No wall found at index ${selectedWallIndex}`);
        return;
    }

    if (type === 'window') {
        createWindow(scene, inputs.width, inputs.height, inputs.distanceFromFloor, inputs.distanceFromWall, selectedWall);
    } else if (type === 'door') {
        createDoor(scene, inputs.width, inputs.height, inputs.distanceFromWall, selectedWall);
    }
}
export function getSelectedWallIndex() {
    const wallSelection = document.getElementById('wall-selection');
    if (!wallSelection) {
        console.error('Wall selection element not found');
        return -1; // Return an invalid index
    }
    const index = parseInt(wallSelection.value, 10);
    if (isNaN(index)) {
        console.error('Invalid wall selection index');
        return -1; // Return an invalid index
    }
    return index;
}

function gatherInputValues(type) {
    const widthInput = document.getElementById(`${type}-width`);
    const heightInput = document.getElementById(`${type}-height`);
    const distanceFromWallInput = document.getElementById(`${type}-distance-from-wall`);
    const distanceFromFloorInput = type === 'window' ? document.getElementById('window-distance-from-floor') : null;

    if (!widthInput || !heightInput || !distanceFromWallInput) {
        console.error(`Input element for ${type} is missing`);
        return null;
    }

    // For windows
    if (type === 'window') {
        return {
            width: parseFloat(widthInput.value),
            height: parseFloat(heightInput.value),
            distanceFromFloor: parseFloat(distanceFromFloorInput.value),
            distanceFromWall: parseFloat(distanceFromWallInput.value)
        };
    }

    // For doors
    if (type === 'door') {
        return {
            width: parseFloat(widthInput.value),
            height: parseFloat(heightInput.value),
            distanceFromWall: parseFloat(distanceFromWallInput.value)
        };
    }
}
// Helper function to ensure objects are within wall limits
function isWithinWallLimits(width, height, distanceFromWall, distanceFromFloor, wall) {
    const wallWidth = (wall === 'front' || wall === 'back') ? config.roomSize.width : config.roomSize.depth;
    const wallHeight = config.roomSize.height;

    // Prevent the object from exceeding the wall's boundaries
    width = clamp(width, 0, wallWidth - distanceFromWall);
    height = clamp(height, 0, wallHeight - distanceFromFloor);

    // Prevent the object from being positioned out of the wall's boundaries
    distanceFromWall = clamp(distanceFromWall, 0, wallWidth - width);
    distanceFromFloor = clamp(distanceFromFloor, 0, wallHeight - height);

    return { width, height, distanceFromWall, distanceFromFloor };
}

// Helper function to clamp values within a range
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}

// Helper function to ensure objects are within wall limits and adjust dimensions and positions
function adjustDimensionsAndPosition(width, height, distanceFromWall, distanceFromFloor, wall) {
    const wallWidth = (wall === 'front' || wall === 'back') ? config.roomSize.width : config.roomSize.depth;
    const wallHeight = config.roomSize.height;

    // Clamp width and height to prevent exceeding wall boundaries
    const clampedWidth = clamp(width, 0, wallWidth - distanceFromWall);
    const clampedHeight = clamp(height, 0, wallHeight - distanceFromFloor);
    // Clamp position to prevent placement out of wall boundaries
    const clampedDistanceFromWall = clamp(distanceFromWall, 0, wallWidth - clampedWidth);
    const clampedDistanceFromFloor = clamp(distanceFromFloor, 0, wallHeight - clampedHeight);

    return {
        clampedWidth,
        clampedHeight,
        clampedDistanceFromWall,
        clampedDistanceFromFloor
    };
}
