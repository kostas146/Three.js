import * as THREE from "three";
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { DragControls } from 'three/examples/jsm/controls/DragControls';
import { config } from '../utils/Config';
import { getModelURL } from './UI'
export function loadModel(scene, camera, renderer, modelName, orbitControls) {
    const loader = new GLTFLoader();
    const modelURL = getModelURL(modelName);

    loader.load(modelURL, (gltf) => {
        const model = gltf.scene;

        // Update model's matrix world to get accurate world coordinates
        model.updateMatrixWorld(true);

        // Get bounding box in world coordinates
        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());

        // Translate model to origin
        model.position.sub(center);

        // Place model at the desired position
        model.position.y = 0;
        scene.add(model);

        // Use the existing orbitControls instance
        const dragControls = new DragControls([model], camera, renderer.domElement);

        dragControls.mouseButton = THREE.MOUSE.RIGHT;

        dragControls.addEventListener('dragstart', (event) => {
            orbitControls.enabled = false;
        });

        dragControls.addEventListener('drag', (event) => {
            // Update the model's matrix world
            event.object.updateMatrixWorld(true);

            // Get the model's bounding box
            const box = new THREE.Box3().setFromObject(event.object);
            const size = box.getSize(new THREE.Vector3());


            // Modify boundaries to consider wall thickness and model dimensions
            const maxX = (config.roomSize.width - size.x) / 2;
            const maxZ = (config.roomSize.depth - size.z) / 2;

            const minX = -maxX;
            const minZ = -maxZ;

            // X boundaries
            if (event.object.position.x > maxX) event.object.position.x = maxX;
            if (event.object.position.x < minX) event.object.position.x = minX;

            // Set the minimum Y-coordinate to half the height of the bounding box
            const minY = size.y / 2;

            // Y position is set to the minimum Y-coordinate, disallowing vertical dragging
            event.object.position.y = minY;

            // Z boundaries
            if (event.object.position.z > maxZ) event.object.position.z = maxZ;
            if (event.object.position.z < minZ) event.object.position.z = minZ;
        });

        dragControls.addEventListener('dragend', (event) => {
            orbitControls.enabled = true;
        });
    }, undefined, (error) => {
        console.error('An error happened while loading the model:', error);
    });
}