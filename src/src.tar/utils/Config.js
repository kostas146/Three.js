export const config = {
    wallThickness: 0,
    roomSize: { width: 24, height: 8, depth: 16 },
    groundColor: 0x006400,
    wallColors: [0xFF0000, 0x00FF00, 0x0000FF, 0xFFFF00, 0xFFFFFF],
    lightColor: 0xFFFFFF,
    lightIntensity: 1,
    ambientLightIntensity: 0.5,
    modelURL: 'http://localhost/wordpress/wp-content/uploads/2023/10/uploads_files_3993850_Chair.glb',
    groundTextureURL: 'http://localhost/wordpress/wp-content/uploads/2023/11/360_F_275270350_Bui4WhKMWO8Jit1IcDZwZR0ZRhuI5Qv7.jpg',
    WallsTextureURL: 'http://localhost/wordpress/wp-content/uploads/2023/11/hima595615_5f1518b830f67.jpg',

};
